#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <iomanip>
#include <time.h>

// ============================================================================================================================
// Heap Sort Function Declarations =============================================================================================
// ============================================================================================================================
void max_heapify(std::vector<int>& arr, int size, int i, int & compCounter, int & swapCounter);
void heap_sort(std::vector<int>& arr);

// ============================================================================================================================
// Heap Sort Function Definitions =============================================================================================
// ============================================================================================================================
void max_heapify(std::vector<int>& arr, int size, int i, int & compCounter, int & swapCounter){
    int largest;
    int left = (2*i) + 1;
    int right = left + 1;

    if(left < size && arr[left] > arr[i]){
        compCounter++;
        largest = left;
    }
    else{
        largest = i;
    }

    if(right < size && arr[right] > arr[largest]){
        compCounter++;
        largest = right;
    }

    if(largest != i){
        swapCounter++;
        std::swap(arr[i], arr[largest]);
        max_heapify(arr, size, largest, compCounter, swapCounter);
    }
}

void heap_sort(std::vector<int>& arr){
    // declare the counters
    int n = arr.size();
    int compCounter = 0;
    int swapCounter = 0;

    // clock variables
    unsigned long c_start, c_end;

    c_start = std::clock();
    for(int i = (n / 2 - 1); i >= 0; i--){
       max_heapify(arr, n, i, compCounter, swapCounter);
    }

    for(int i = n - 1; i >= 0; i--){
        swapCounter++;
        std::swap(arr[0], arr[i]);
        n--;
        max_heapify(arr, n, 0, compCounter, swapCounter);
    }
    c_end = std::clock();

    std::cout << "Start: " << c_start << "\nEnd: " << c_end << "\n";
    std::cout << "\tNumber of Comparisons: " << compCounter << "\n\tNumber of Swaps: " << swapCounter << "\n";
    std::cout << "\tRun Time: " << std::fixed << std::setprecision(8) << 1.0 * (c_end - c_start)/CLOCKS_PER_SEC << "\n";
}