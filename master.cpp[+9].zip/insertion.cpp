#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <iomanip>
#include <time.h>

// ============================================================================================================================
// Insertion Sort Function Declarations =============================================================================================
// ============================================================================================================================
void insertion_sort(std::vector<int> &data);

// ============================================================================================================================
// Insertion Sort Function Definitions =============================================================================================
// ============================================================================================================================
void insertion_sort(std::vector<int> &data) {
    unsigned long c_start, c_end;
    int num_comparisons = 0;
    int num_swaps = 0;

    c_start = std::clock();
    for (int i = 0; i < data.size(); i++) {
        for (int j = i; j > 0; j--) {
            num_comparisons++;
            if (data[j] < data[j - 1]) {
                num_swaps++;
                std::swap(data[j], data[j - 1]);
            } else {
                break;
            }
        }
    }
    c_end = std::clock();

    std::cout << "Start: " << c_start << "\nEnd: " << c_end << "\n";

    std::cout << "\tNumber of Comparisons: " << num_comparisons << "\n\tNumber of Swaps: " << num_swaps << "\n";
    std::cout << "\tRun Time: " << std::fixed << std::setprecision(8) << 1.0 * (c_end - c_start)/CLOCKS_PER_SEC << "\n";

}