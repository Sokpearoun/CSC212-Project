#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <iomanip>
#include <time.h>
#include "quick.cpp"
#include "insertion.cpp"
#include "merge.cpp"
#include "heap.cpp"

// run this: ./master best.txt worst.txt random.txt large.txt

// ============================================================================================================================
// Other Function Declarations =============================================================================================
// ============================================================================================================================
void swap(std::vector<int> &data, int j);
void write_data(std::string fname, std::vector<std::vector<int>> &test_cases);
void print_data(std::vector<int> &data);
// ============================================================================================================================
// Main ============================================================================================================================
// ============================================================================================================================

int main(int argc, char** argv) {

    std::vector<std::vector<int>> insertion;
    std::vector<std::vector<int>> quick;
    std::vector<std::vector<int>> merge;
    std::vector<std::vector<int>> heap;

    // write separate datasets for each algorithm to their own vector of vectors
    for (int i = 0; i < argc - 1; i++) {
        write_data(argv[i + 1], insertion);
        write_data(argv[i + 1], quick);
        write_data(argv[i + 1], merge);
        write_data(argv[i + 1], heap);
    }

    std::cout << "=======================================================================================================\n";
    for (int i = 0; i < argc - 1; i++) {

        // insertion sort
        std::cout << argv[i + 1];
        std::cout << "\nInsertion Sort Stats:\n";
        insertion_sort(insertion[i]);
        std::cout << "\n";
        std::cout << "*****************************************************************************************************\n";
        // quick sort
        std::cout << "\nQuick Sort Stats:\n";
        quickSort(quick[i]);
        std::cout << "\n";
        std::cout << "*****************************************************************************************************\n";
        // merge sort
        std::cout << "\nMerge Sort Stats:\n";
        mergeSortDriver(merge[i]);
        std::cout << "\n";
        std::cout << "*****************************************************************************************************\n";
        // heap sort
        std::cout << "\nHeap Sort Stats:\n";
        heap_sort(heap[i]);
        std::cout << "\n";

        std::cout << "=======================================================================================================\n";
    }

    return 0;
}

// ============================================================================================================================
// End of Main ============================================================================================================================
// ============================================================================================================================


// ============================================================================================================================
// Other Function Definitions =================================================================================================
// ============================================================================================================================
void write_data(std::string fname, std::vector<std::vector<int>> &test_cases) {

    std::ifstream myFile;
    myFile.open(fname, std::ifstream::in);
    std::string val;

    // Dynamic memory on the heap, new vector declared
    std::vector<int> *data = new std::vector<int>;

    while(std::getline(myFile, val, ',')) {
        // std::cout << val << "\n";
        data->push_back(std::stoi(val));
    }

    test_cases.push_back(*data);

    // Delete dynamic data storage to prevent data leak
    delete data;

}

void print_data(std::vector<int> &data) {
    for (int i = 0; i < data.size(); i++) {
        std::cout << data[i] << " ";

    }
    std::cout << "\n";
}
