#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <iomanip>
#include <time.h>

// ============================================================================================================================
// Quick Sort Function Declarations =============================================================================================
// ============================================================================================================================
int Partition(std::vector<int> & array, int left, int right, int &num_comparisons, int &num_swaps);
void QSort(std::vector<int> & array, int left, int right, int &num_comparisons, int &num_swaps);
void quickSort(std::vector<int> & array);

// ============================================================================================================================
// Quick Sort Function Definitions =============================================================================================
// ============================================================================================================================
int Partition(std::vector<int> & array, int left, int right, int &num_comparisons, int &num_swaps){

	int key = array[left];
	while (left < right){
		num_comparisons++;
		while (left < right && array[right] >= key){
			right--;
		}
		std::swap(array[left], array[right]);
		num_swaps++;
		while (left < right && array[left] <= key){
			left ++;
		}
		std::swap(array[left], array[right]);
		num_swaps++;
	}
	return left;
}

void QSort(std::vector<int> & array, int left, int right, int &num_comparisons, int &num_swaps){
	int pivot;
	if (left < right){
	    pivot = Partition(array, left, right, num_comparisons, num_swaps);
		QSort(array, left, pivot - 1, num_comparisons, num_swaps);
		QSort(array, pivot + 1, right, num_comparisons, num_swaps);
	}
}

void quickSort(std::vector<int> & array){
    unsigned long c_start, c_end;
    int num_comparisons = 0;
    int num_swaps = 0;

    c_start = std::clock();
	QSort(array, 0, array.size()-1, num_comparisons, num_swaps);
	c_end = std::clock();

	std::cout << "Start: " << c_start << "\nEnd: " << c_end << "\n";

    std::cout << "\tNumber of Comparisons: " << num_comparisons << "\n\tNumber of Swaps: " << num_swaps << "\n";
    std::cout << "\tRun Time: " << std::fixed << std::setprecision(8) << 1.0 * (c_end - c_start)/CLOCKS_PER_SEC << "\n";
}