#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <iomanip>
#include <time.h>

// ============================================================================================================================
// Merge Sort Function Declarations =============================================================================================
// ============================================================================================================================
void mergeSortDriver(std::vector<int>& array);
void mergeSort(std::vector<int>& array, int left, int right, int& num_comparisons, int& num_swaps);
void merge(std::vector<int>& array, int left, int mid, int right, int& num_comparisons, int& num_swaps);

// ============================================================================================================================
// Merge Sort Function Definitions =============================================================================================
// ============================================================================================================================
void mergeSortDriver(std::vector<int>& array) {
    int num_comparisons = 0;
    int num_swaps = 0;
    int left = 0;
    int right = array.size() - 1;
    unsigned long c_start = std::clock();
    mergeSort(array, left, right, num_comparisons, num_swaps);
    unsigned long c_end = std::clock();

    std::cout << "Start: " << c_start << "\nEnd: " << c_end << "\n";

    std::cout << "\tNumber of Comparisons: " << num_comparisons << "\n\tNumber of Swaps: " << num_swaps << "\n";
	std::cout << "\tRun Time: " << std::fixed << std::setprecision(8) << 1.0 * (c_end - c_start)/CLOCKS_PER_SEC << "\n";
}

void mergeSort(std::vector<int>& array, int left, int right, int& num_comparisons, int& num_swaps) {
    int mid = (left + (right - 1))/2;
    // Repeatedly break down the vect by half until there is only one value left.
    if (left < right) {
        mergeSort(array, left, mid, num_comparisons, num_swaps);
        mergeSort(array, mid + 1, right, num_comparisons, num_swaps);
        // Merge the broken down vect, sorting it during the process
        merge(array, left, mid, right, num_comparisons, num_swaps);
    }
    else return;
}

void merge(std::vector<int>& array, int left, int mid, int right, int& num_comparisons, int& num_swaps) {
    // Create temp left and right vectors
    int sizeLeft = (mid - left) + 1;
    int sizeRight = (right - mid);
    std::vector<int> leftVect;
    std::vector<int> rightVect;
    // Place values left of mid + mid into leftVect
    for (int i = left; i < left + sizeLeft; i++) {
        leftVect.push_back(array[i]);
    }
    // Place values right of mid into rightVect
    for (int i = mid + 1; i < mid + 1 + sizeRight; i++) {
        rightVect.push_back(array[i]);
    }
    // Now place values in temp into original by correct order
    int pos = left; // Starting index for original vect
    int i = 0; // Temp left index
    int j = 0; // Temp right index

    while (i < sizeLeft && j < sizeRight) {
        // Compare values of leftVect with rightVect
        num_comparisons++;
        if (leftVect[i] > rightVect[j]) {
            // rightVect carries a smaller value
            // place value into original vect
            array[pos] = rightVect[j];
            j++;
            num_swaps++;
        }
        else {
            // leftVect carries a smaller value
            // place value into original vect
            array[pos] = leftVect[i];
            i++;
        }
        pos++;
    }
    // Get rid of remaining values from leftVect
    while (i < sizeLeft) {
        array[pos] = leftVect[i];
        i++;
        pos++;
    }
    // Get rid of remaining values from rightVect
    while (j < sizeRight) {
        array[pos] = rightVect[j];
        j++;
        pos++;
    }

    return;
}